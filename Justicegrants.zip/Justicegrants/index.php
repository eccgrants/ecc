<?php include 'antibot.php'  ?>
<!doctype html>
<html lang="en-US" class="no-js">
  
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />

	<!-- This site is optimized with the Yoast SEO plugin v21.3 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Economic Justice Fund</title>
	<meta name="description" content="The Economic Justice Fund is a mission-driven, nonprofit lender dedicated to helping Americans pursue the American Dream." />
	<link rel="canonical" href="index.php" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="Economic Justice Fund" />
	<meta property="og:description" content="The Economic Justice Fund is a mission-driven, nonprofit lender dedicated to helping Americans pursue the American Dream." />
	<meta property="og:url" content="" />
	<meta property="og:site_name" content="Economic Justice Fund" />
	<meta property="article:modified_time" content="2023-03-30T04:31:39+00:00" />
	<meta property="og:image" content="https://economicjusticefund.org/wp-content/uploads/ejf-opengraph-2.jpg" />
	<meta property="og:image:width" content="1200" />
	<meta property="og:image:height" content="630" />
	<meta property="og:image:type" content="image/jpeg" />
	<meta name="twitter:card" content="summary_large_image" />
	<meta name="twitter:image" content="https://economicjusticefund.org/wp-content/uploads/ejf-opengraph-2.jpg" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebPage","@id":"https://economicjusticefund.org/","url":"https://economicjusticefund.org/","name":"Economic Justice Fund","isPartOf":{"@id":"https://economicjusticefund.org/#website"},"primaryImageOfPage":{"@id":"https://economicjusticefund.org/#primaryimage"},"image":{"@id":"https://economicjusticefund.org/#primaryimage"},"thumbnailUrl":"https://economicjusticefund.org/wp-content/uploads/image-10.jpg","datePublished":"2019-12-02T18:46:08+00:00","dateModified":"2023-03-30T04:31:39+00:00","description":"The Economic Justice Fund is a mission-driven, nonprofit lender dedicated to helping Americans pursue the American Dream.","breadcrumb":{"@id":"https://economicjusticefund.org/#breadcrumb"},"inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["https://economicjusticefund.org/"]}]},{"@type":"ImageObject","inLanguage":"en-US","@id":"https://economicjusticefund.org/#primaryimage","url":"https://economicjusticefund.org/wp-content/uploads/image-10.jpg","contentUrl":"https://economicjusticefund.org/wp-content/uploads/image-10.jpg","width":1440,"height":899},{"@type":"BreadcrumbList","@id":"https://economicjusticefund.org/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Homepage"}]},{"@type":"WebSite","@id":"https://economicjusticefund.org/#website","url":"https://economicjusticefund.org/","name":"Economic Justice Fund","description":"Advancing Economic Opportunity for All","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://economicjusticefund.org/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->



<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='vc_extend-css' href='wp-content/plugins/visceral-vc-visceral-addons/assets/vc_extend9b30.css?ver=6.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min192d.css?ver=5.23.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='wp-content/plugins/elementor/assets/css/frontend-lite.minafc7.css?ver=3.16.4' type='text/css' media='all' />
<link rel='stylesheet' id='swiper-css' href='wp-content/plugins/elementor/assets/lib/swiper/css/swiper.min48f5.css?ver=5.3.6' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-1436-css' href='wp-content/uploads/elementor/css/post-1436456e.css?ver=1696289426' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css' href='wp-content/plugins/elementor-pro/assets/css/frontend-lite.min6b60.css?ver=3.16.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-5-css' href='wp-content/uploads/elementor/css/post-5d7fd.css?ver=1696289427' type='text/css' media='all' />
<link rel='stylesheet' id='sage/main.css-css' href='wp-content/themes/ejf/dist/styles/main.css' type='text/css' media='all' />
<link rel='stylesheet' id='adobe-fonts-css' href='../use.typekit.net/bud6dex.css' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=auto&amp;ver=6.3.1' type='text/css' media='all' />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin><script type='text/javascript' src='wp-includes/js/jquery/jquery.min3088.js?ver=3.7.0' id='jquery-core-js'></script>
<script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min5589.js?ver=3.4.1' id='jquery-migrate-js'></script>
<script type='text/javascript' src='wp-content/plugins/visceral-vc-visceral-addons/assets/vc_extend9b30.js?ver=6.3.1' id='vc_extend_js-js'></script>
<script type='text/javascript' src='wp-content/plugins/visceral-vc-visceral-addons/assets/waypoints9b30.js?ver=6.3.1' id='waypoints-js'></script>
<script type='text/javascript' src='wp-content/plugins/visceral-vc-visceral-addons/assets/counterup9b30.js?ver=6.3.1' id='counterup-js'></script>
<script type='text/javascript' src='../widget.trustpilot.com/bootstrap/v5/tp.widget.bootstrap.min.js' id='trustpilot-js'></script>
<script type='text/javascript' src='wp-content/plugins/visceral-vc-visceral-addons/widgets/assets/js/visc-posts9b30.js?ver=6.3.1' id='visc-posts-script-js'></script>
<link rel="https://api.w.org/" href="wp-json/index.php" /><link rel="alternate" type="application/json" href="wp-json/wp/v2/pages/5.json" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.html?rsd" />
<meta name="generator" content="WordPress 6.3.1" />
<link rel='shortlink' href='index.php' />
<link rel="alternate" type="application/json+oembed" href="wp-json/oembed/1.0/embedfe31.json?url=https%3A%2F%2Feconomicjusticefund.org%2F" />
<link rel="alternate" type="text/xml+oembed" href="wp-json/oembed/1.0/embedd79c?url=https%3A%2F%2Feconomicjusticefund.org%2F&amp;format=xml" />
<meta name="generator" content="Site Kit by Google 1.110.0" /><!-- Stream WordPress user activity plugin v3.9.3 -->
<meta name="generator" content="Elementor 3.16.4; features: e_dom_optimization, e_optimized_assets_loading, e_optimized_css_loading, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-auto">

<!-- Google Tag Manager snippet added by Site Kit -->
<script type="text/javascript">
			( function( w, d, s, l, i ) {
				w[l] = w[l] || [];
				w[l].push( {'gtm.start': new Date().getTime(), event: 'gtm.js'} );
				var f = d.getElementsByTagName( s )[0],
					j = d.createElement( s ), dl = l != 'dataLayer' ? '&l=' + l : '';
				j.async = true;
				j.src = '../www.googletagmanager.com/gtm5445.html?id=' + i + dl;
				f.parentNode.insertBefore( j, f );
			} )( window, document, 'script', 'dataLayer', 'GTM-PRFDHD9' );
			
</script>

<!-- End Google Tag Manager snippet added by Site Kit -->
<link rel="icon" href="wp-content/uploads/cropped-ejf-favicon-1-32x32.png" sizes="32x32" />
<link rel="icon" href="wp-content/uploads/cropped-ejf-favicon-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="wp-content/uploads/cropped-ejf-favicon-1-180x180.png" />
<meta name="msapplication-TileImage" content="https://economicjusticefund.org/wp-content/uploads/cropped-ejf-favicon-1-270x270.png" />
</head>

  <body class="home page-template-default page page-id-5 app-data index-data singular-data page-data page-5-data page-homepage-data front-page-data elementor-default elementor-kit-1436 elementor-page elementor-page-5">
    <a id="skip-to-content" href="#main-content" class="no-print" aria-label="Skip to content" title="Skip to content">Skip to content</a>
        <header class="header header--img-bg">
    <div class="header__inner">
        <a class="header__brand" href="">
            <span class="screen-reader-text">Economic Justice Fund</span>
            <svg width="216px" height="76px" viewBox="0 0 216 76" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="menu-black-text" transform="">
                        <g id="Menu">
                            <rect id="Rectangle" x="0" y="0" width="1440" height="97"></rect>
                        </g>
                        <g id="ejf-logo" transform="">
                            <g id="logo-mark" transform="">
                                <rect id="square" fill="#0B0B0B" x="0" y="0.0151525469" width="75.8801961" height="75.7627345"></rect>
                                <path d="M30.5971497,32.827707 C25.922856,30.7071828 24.8160851,26.7111157 27.276837,20.8395056 C30.9679648,12.0320904 39.7573175,14.4639222 36.4558223,5.99103137 C42.0741917,7.4595032 47.6266693,11.641254 47.2660295,15.7383356 C47.0408211,18.296837 46.7760548,19.013509 43.9537538,20.9524029 C42.0722198,22.2449987 41.6190654,23.9230493 42.5942905,25.9865546 C42.5720808,24.4869629 43.5607822,23.6528341 45.5603946,23.4841684 C48.5598133,23.2311699 49.4677929,21.0851379 48.778277,20.4525768 C48.088761,19.8200157 50.5814674,21.353665 49.7223638,28.3368098 C48.8632602,35.3199545 39.0068005,35.4127252 40.0522865,34.8326414 C41.0977726,34.2525575 41.3006364,32.34588 40.7470481,31.3927755 C40.3779892,30.7573725 39.6012901,30.0251156 38.4169507,29.196005 C39.2667279,31.9720945 38.5982179,33.953199 36.4114208,35.1393184 C34.2246237,36.3254379 32.5258397,36.2073209 31.3150686,34.7849674 C33.6887303,34.0032875 34.1133626,32.3554999 32.5889653,29.8416045 C30.3023694,26.0707614 34.3863278,23.2161847 34.6880805,22.7282129 C33.595904,22.8227248 28.8662274,25.1701228 29.1961,28.6155877 C29.416015,30.9125643 29.8830316,32.3166041 30.5971497,32.827707 Z" id="flame" fill="#BC0E0E" transform="translate(37.954299, 20.969687) rotate(-5.000000) translate(-37.954299, -20.969687) "></path>
                                <path d="M30.0065501,66.4744275 C33.8982905,66.7674083 36.936184,67.6569851 39.1202306,69.143158 C41.7071423,70.9034676 43.4719586,72.7010013 44.4146793,74.5357591 L44.143677,75.8912688 L32.334677,75.8912688 L30.0065501,66.4744275 Z M47.9787571,60.401289 C49.0401829,60.401289 49.9006384,61.2617446 49.9006384,62.3231703 C49.9006384,63.384596 49.0401829,64.2450516 47.9787571,64.2450516 L27.4974969,64.2450516 C26.4360711,64.2450516 25.5756156,63.384596 25.5756156,62.3231703 C25.5756156,61.2617446 26.4360711,60.401289 27.4974969,60.401289 L47.9787571,60.401289 Z M37.879435,40.9082688 L38.8236555,40.9133862 C45.0905714,40.9689726 48.6626258,41.4523602 49.8708176,42.5337993 L49.9283325,42.5874678 L50.1770592,42.8296652 L50.1779735,44.5418159 C50.9782655,44.7238932 51.7117293,44.9791319 52.3769024,45.307213 C53.244726,44.8071951 54.242457,44.5302814 55.3649784,44.4840659 L55.7054734,44.4771297 L56.5347356,44.4771297 L56.5347356,53.5494644 C56.3747605,53.5799672 56.216609,53.6117047 56.0602809,53.6446769 L32.6383808,53.6449432 C36.3138312,54.2842055 40.2576203,55.3306837 44.469748,56.7843778 C45.2842601,57.0654831 46.0105844,57.3557637 46.6487206,57.6552195 L26.3079206,57.6550388 C24.8631072,55.8172459 22.3561284,54.4789122 18.7869843,53.6400378 L18.388677,53.5494644 L18.388677,44.4771297 L19.2179392,44.4771297 C20.7773966,44.4771297 22.1262296,44.8443443 23.254713,45.565668 C23.8806607,45.2145772 24.5625755,44.9306162 25.2989308,44.7147383 L25.2991949,42.8974523 L25.469003,42.6762367 C26.4254552,41.4302298 30.0642425,40.9371159 36.9188539,40.9091871 L37.879435,40.9082688 Z M52.4677621,47.2697931 L52.3097776,47.4172854 C51.6855133,48.0269373 51.1757673,48.8570283 50.7753873,49.9177319 L50.6585492,50.2428715 L54.7332082,50.2422795 C54.2460808,48.9764898 53.4957327,47.9867081 52.4677621,47.2697931 Z M42.3451065,46.6431571 L42.2552984,46.6808329 C40.59467,47.3959723 39.3554385,48.5741498 38.5133108,50.2208809 L38.519677,50.2422688 L45.6174179,50.2426041 C44.9891324,48.5529786 43.9097356,47.3563894 42.3451065,46.6431571 Z M33.5681122,46.6748221 L33.4508224,46.72644 C31.8900612,47.4482775 30.7223887,48.6177909 29.9245358,50.2418131 L36.771955,50.2426041 L36.7659022,50.2263791 L36.6975318,50.1974574 L36.7282222,50.1276635 C36.1036447,48.5230284 35.0604168,47.3749583 33.5681122,46.6748221 Z M29.1922431,45.8499021 C27.4005053,45.8499021 25.8786134,46.1395085 24.6142316,46.7223435 C25.435862,47.6284451 26.0828165,48.8049906 26.5491518,50.2424209 L28.215677,50.2422688 L28.1250267,50.2057448 C28.8649591,48.4073295 29.9550433,47.0096585 31.3799623,46.0172294 C30.7096558,45.9056431 29.9808353,45.8499021 29.1922431,45.8499021 Z M46.8925307,45.8499021 C46.0485136,45.8499021 45.2623088,45.9101458 44.5327603,46.0308957 C45.8235161,47.0008165 46.7574416,48.354491 47.3173061,50.0869118 L47.365677,50.2422688 L48.9194066,50.2417032 C49.3889932,48.6715256 50.05975,47.410844 50.9246189,46.4735947 C49.8036865,46.0570073 48.4624434,45.8499021 46.8925307,45.8499021 Z M23.1707081,47.601096 L23.0005208,47.7390944 C22.2135016,48.3989087 21.5748804,49.2326017 21.0790729,50.2418131 L24.793677,50.2422688 L24.6986522,49.9971962 C24.2961385,49.0036525 23.7885078,48.2072219 23.1707081,47.601096 Z M20.0472013,46.1689344 L20.0463396,48.684494 C20.5284704,47.8952087 21.0995432,47.2094309 21.7575577,46.627748 C21.2901965,46.4141157 20.7797332,46.2693543 20.2260638,46.19182 L20.0472013,46.1689344 Z M38.037706,45.8499021 C37.1999875,45.8499021 36.421257,45.9132096 35.7002536,46.0401949 C36.5138712,46.6546417 37.1849938,47.4216928 37.7095558,48.3404881 C38.3587661,47.3979896 39.1488861,46.615535 40.0756131,45.9941597 C39.4480124,45.8977751 38.7685266,45.8499021 38.037706,45.8499021 Z M54.8762113,46.1799166 L54.7924091,46.1920867 C54.5220098,46.2340654 54.2628954,46.2956914 54.0149175,46.3772575 C54.3254123,46.6417372 54.6127137,46.9296973 54.8767798,47.2415242 L54.8762113,46.1799166 Z M37.1888831,42.5557033 L36.4825217,42.5593403 C33.5883172,42.5820653 31.306377,42.6993805 29.6430009,42.9096679 C28.3258668,43.0761827 27.4310823,43.3060112 27.0181636,43.5120493 L26.9577192,43.5436445 L26.9574921,44.3567971 C27.6623267,44.254049 28.4074702,44.2025753 29.1922431,44.2025753 C30.8567299,44.2025753 32.3220081,44.4351654 33.5799122,44.8980294 C34.8819265,44.4349251 36.3703738,44.2025753 38.037706,44.2025753 C39.6760392,44.2025753 41.121375,44.4279136 42.3659264,44.8763815 C43.6911891,44.4277082 45.2024334,44.2025753 46.8925307,44.2025753 C47.4569755,44.2025753 47.999127,44.2277984 48.5186915,44.2781806 L48.5185349,43.5886715 L48.479033,43.5673867 C47.3157908,42.9676561 43.7806091,42.58227 38.1561453,42.5566142 L37.1888831,42.5557033 Z" id="torch" fill="#FFFFFF" fill-rule="nonzero"></path>
                                <path d="M102.162374,27.9135082 L102.162374,24.2700553 L95.4236891,24.2700553 L95.4236891,22.4266417 L102.007207,22.4266417 L102.007207,18.7831888 L95.4236891,18.7831888 L95.4236891,17.0915857 L102.162374,17.0915857 L102.162374,13.4481328 L90.9460106,13.4481328 L90.9460106,27.9135082 L102.162374,27.9135082 Z M111.859505,27.9135082 C115.751751,27.9135082 117.67625,25.6196067 118.51957,23.693595 L114.757066,21.9623486 C114.389465,23.0876588 113.265038,24.0614849 111.859505,24.0614849 C109.870136,24.0614849 108.464603,22.460082 108.464603,20.447508 C108.464603,18.434934 109.870136,16.8335311 111.859505,16.8335311 C113.265038,16.8335311 114.389465,17.8073572 114.757066,18.9326674 L118.51957,17.1797804 C117.654626,15.188847 115.751751,12.9815078 111.859505,12.9815078 C107.448294,12.9815078 104.031767,15.9895485 104.031767,20.447508 C104.031767,24.883827 107.448294,27.9135082 111.859505,27.9135082 Z M128.333887,27.9135082 C132.817872,27.9135082 136.278811,24.883827 136.278811,20.447508 C136.278811,16.0111891 132.817872,12.9815078 128.333887,12.9815078 C123.849903,12.9815078 120.388964,16.0111891 120.388964,20.447508 C120.388964,24.883827 123.849903,27.9135082 128.333887,27.9135082 Z M128.100213,24.1805081 C125.975238,24.1805081 124.5951,22.5263643 124.5951,20.447508 C124.5951,18.3686517 125.975238,16.7145079 128.100213,16.7145079 C130.225188,16.7145079 131.605327,18.3686517 131.605327,20.447508 C131.605327,22.5263643 130.225188,24.1805081 128.100213,24.1805081 Z M142.559625,27.9135082 L142.559625,20.1494836 L147.931949,27.9135082 L152.168659,27.9135082 L152.168659,13.4481328 L147.757239,13.4481328 L147.757239,20.7350386 L142.690657,13.4481328 L138.148205,13.4481328 L138.148205,27.9135082 L142.559625,27.9135082 Z M162.450325,27.9135082 C166.93431,27.9135082 170.395249,24.883827 170.395249,20.447508 C170.395249,16.0111891 166.93431,12.9815078 162.450325,12.9815078 C157.966341,12.9815078 154.505401,16.0111891 154.505401,20.447508 C154.505401,24.883827 157.966341,27.9135082 162.450325,27.9135082 Z M162.216651,24.1805081 C160.091676,24.1805081 158.711537,22.5263643 158.711537,20.447508 C158.711537,18.3686517 160.091676,16.7145079 162.216651,16.7145079 C164.341626,16.7145079 165.721764,18.3686517 165.721764,20.447508 C165.721764,22.5263643 164.341626,24.1805081 162.216651,24.1805081 Z M177.142297,27.9135082 L177.142297,18.7831888 L180.395444,27.9135082 L182.360432,27.9135082 L185.613578,18.7831888 L185.613578,27.9135082 L190.023884,27.9135082 L190.023884,13.4481328 L183.932422,13.4481328 L181.377938,20.8217874 L178.823454,13.4481328 L172.731991,13.4481328 L172.731991,27.9135082 L177.142297,27.9135082 Z M197.50146,27.9135082 L197.50146,13.4481328 L193.295324,13.4481328 L193.295324,27.9135082 L197.50146,27.9135082 Z M207.66594,27.9135082 C211.558185,27.9135082 213.482684,25.6196067 214.326004,23.693595 L210.5635,21.9623486 C210.1959,23.0876588 209.071473,24.0614849 207.66594,24.0614849 C205.67657,24.0614849 204.271037,22.460082 204.271037,20.447508 C204.271037,18.434934 205.67657,16.8335311 207.66594,16.8335311 C209.071473,16.8335311 210.1959,17.8073572 210.5635,18.9326674 L214.326004,17.1797804 C213.461061,15.188847 211.558185,12.9815078 207.66594,12.9815078 C203.254729,12.9815078 199.838202,15.9895485 199.838202,20.447508 C199.838202,24.883827 203.254729,27.9135082 207.66594,27.9135082 Z M94.122717,45.1786336 C97.5488865,45.1786336 99.8256313,43.4413317 99.8256313,39.6808426 L99.8256313,30.2466333 L95.3605589,30.2466333 L95.3605589,39.6148691 C95.3605589,40.6484538 94.6974293,41.2642064 93.7248393,41.2642064 C92.9732924,41.2642064 92.3101628,40.934339 91.8238678,40.6044715 L90.0113136,43.9911108 C91.1607382,44.8707573 92.6859363,45.1786336 94.122717,45.1786336 Z M109.183537,45.1786336 C114.104913,45.1786336 116.182827,42.5177028 116.182827,38.8671696 L116.182827,30.2466333 L111.698907,30.2466333 L111.698907,38.7352226 C111.698907,40.1426571 110.977105,41.2642064 109.183537,41.2642064 C107.368096,41.2642064 106.646294,40.1426571 106.646294,38.7352226 L106.646294,30.2466333 L102.162374,30.2466333 L102.162374,38.8891607 C102.162374,42.5177028 104.262161,45.1786336 109.183537,45.1786336 Z M124.835808,45.1786336 C128.752782,45.1786336 131.137978,43.3365146 131.137978,40.1507322 C131.137978,36.8132459 127.571125,36.1197423 125.164046,35.7079745 C123.610386,35.4479106 123.019557,35.2528627 123.019557,34.689391 C123.019557,34.3209672 123.260265,33.9308714 124.354392,33.9308714 C125.514166,33.9308714 127.155357,34.4076551 128.424544,35.3612226 L130.787858,32.2621282 C129.124785,30.9184649 126.980296,30.2466333 124.5951,30.2466333 C120.590596,30.2466333 118.533637,32.4788481 118.533637,34.9277829 C118.533637,38.547005 122.209903,39.1104767 124.616982,39.5439165 C126.06123,39.8039804 126.673941,40.0857162 126.673941,40.6491879 C126.673941,41.2126597 125.886169,41.4943955 125.054633,41.4943955 C123.085205,41.4943955 121.444014,40.6708599 120.349888,39.6306045 L118.052221,42.8814028 C119.605881,44.2684101 121.728487,45.1786336 124.835808,45.1786336 Z M139.887176,44.7120086 L139.887176,34.0635839 L143.756387,34.0635839 L143.756387,30.2466333 L131.605327,30.2466333 L131.605327,34.0635839 L135.496274,34.0635839 L135.496274,44.7120086 L139.887176,44.7120086 Z M149.831917,44.7120086 L149.831917,30.2466333 L145.625781,30.2466333 L145.625781,44.7120086 L149.831917,44.7120086 Z M159.529048,45.1786336 C163.421294,45.1786336 165.345793,42.8847321 166.189113,40.9587205 L162.426609,39.2274741 C162.059008,40.3527842 160.934582,41.3266103 159.529048,41.3266103 C157.539679,41.3266103 156.134146,39.7252074 156.134146,37.7126334 C156.134146,35.7000595 157.539679,34.0986565 159.529048,34.0986565 C160.934582,34.0986565 162.059008,35.0724826 162.426609,36.1977928 L166.189113,34.4449058 C165.324169,32.4539724 163.421294,30.2466333 159.529048,30.2466333 C155.117837,30.2466333 151.701311,33.2546739 151.701311,37.7126334 C151.701311,42.1489524 155.117837,45.1786336 159.529048,45.1786336 Z M178.807521,44.7120086 L178.807521,41.0685558 L172.068837,41.0685558 L172.068837,39.2251421 L178.652354,39.2251421 L178.652354,35.5816892 L172.068837,35.5816892 L172.068837,33.8900861 L178.807521,33.8900861 L178.807521,30.2466333 L167.591158,30.2466333 L167.591158,44.7120086 L178.807521,44.7120086 Z M95.4236891,62.4437591 L95.4236891,56.9568925 L102.007207,56.9568925 L102.007207,53.3134397 L95.4236891,53.3134397 L95.4236891,51.6218366 L102.162374,51.6218366 L102.162374,47.9783837 L90.9460106,47.9783837 L90.9460106,62.4437591 L95.4236891,62.4437591 Z M111.052931,62.9103841 C115.974307,62.9103841 118.052221,60.2494532 118.052221,56.59892 L118.052221,47.9783837 L113.568301,47.9783837 L113.568301,56.466973 C113.568301,57.8744075 112.846499,58.9959569 111.052931,58.9959569 C109.23749,58.9959569 108.515688,57.8744075 108.515688,56.466973 L108.515688,47.9783837 L104.031767,47.9783837 L104.031767,56.6209112 C104.031767,60.2494532 106.131555,62.9103841 111.052931,62.9103841 Z M125.735081,62.4437591 L125.735081,54.6797345 L131.107404,62.4437591 L135.344114,62.4437591 L135.344114,47.9783837 L130.932694,47.9783837 L130.932694,55.2652894 L125.866113,47.9783837 L121.323661,47.9783837 L121.323661,62.4437591 L125.735081,62.4437591 Z M144.204732,62.4437591 C148.764898,62.4437591 152.168659,59.8196055 152.168659,55.2002278 C152.168659,50.58085 148.764898,47.9783837 144.182913,47.9783837 L137.680857,47.9783837 L137.680857,62.4437591 L144.204732,62.4437591 Z M143.981878,58.710759 L141.886993,58.710759 L141.886993,51.7113838 L144.003699,51.7113838 C146.360445,51.7113838 147.495174,53.2001398 147.495174,55.1999613 C147.495174,57.0664613 146.185871,58.710759 143.981878,58.710759 Z" id="work-mark" fill="#171717" fill-rule="nonzero"></path>
                            </g>
                        </g>
                    </g>
                </g>
            </svg>
        </a>
        <div class="header__search">
            <div>
		
                <form >
			
                </form>
            </div>
        </div>
        <nav class="header__navigation">
                            <ul class="main-menu "><li class="main-menu__item  main-menu__item--1408"><class="main-menu__link"></a></li>

</ul>
               
            <div class="header__search-close">
                <i class="icon-close" aria-label="Close"><span class="screen-reader-text">Close</span></i>
            </div>
        </nav>

                    <ul id="menu-quicklinks" class="quicklinks"><li id="menu-item-1246" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1246"><a href="login.php">Login</a></li>
</ul>
        
        <label class="mobile-nav__icon no-print" id="mobile-nav-icon" for="nav-toggle" tabindex="0">
            <span class="screen-reader-text">Navigation Toggle</span>
            <div>
                <div class="mobile-nav__menu-line"></div>
                <div class="mobile-nav__menu-line"></div>
                <div class="mobile-nav__menu-line"></div>
                <div class="mobile-nav__menu-line"></div>
            </div>
        </label>
    </div>
</header>



<input type="checkbox" id="nav-toggle">

<div id="mobile-nav">
	<div class="mobile-nav no-print">
                    <ul id="menu-mobile-menu" class="mobile-nav__menu"><li id="menu-item-2040" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2040"><Menu></Menu></a><span class="icon icon-chevron-down sub-menu--open"></span></li>

</ul>
        
        
        <div class="mobile-nav__searc">
            
		<button class="hhghf" onclick="document.location='App.php'">Apply</button>
		<button class="hhghf" onclick="document.location='login.php'">Login</button>
		
        </div>s
	</div>
</div>        <div class="wrap" role="document">
      <div class="content">
        <main class="main" id="main-content">
                 <div data-elementor-type="wp-page" data-elementor-id="5" class="elementor elementor-5" data-elementor-post-type="page">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-68c232fa masthead masthead--front elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="68c232fa" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-6c1d798a" data-id="6c1d798a" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-13b984e0 text-slide-up elementor-widget elementor-widget-text-editor" data-id="13b984e0" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.16.0 - 20-09-2023 */
.elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap{background-color:#69727d;color:#fff}.elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap{color:#69727d;border:3px solid;background-color:transparent}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap{margin-top:8px}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap-letter{width:1em;height:1em}.elementor-widget-text-editor .elementor-drop-cap{float:left;text-align:center;line-height:1;font-size:50px}.elementor-widget-text-editor .elementor-drop-cap-letter{display:inline-block}</style> <h1>Congrats!!! You Qualify For a Grants</h1><button class="hhghf" onclick="document.location='App.php'">Claim Grants</button>			<p></p>			</div>

				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-27d92fe" data-id="27d92fe" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-1fee0b8 elementor-section-full_width elementor-section-stretched elementor-reverse-mobile elementor-section-height-default elementor-section-height-default" data-id="1fee0b8" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-41ad612" data-id="41ad612" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-ac1acd3 scroll-down-animation elementor-absolute elementor-invisible elementor-widget elementor-widget-html" data-id="ac1acd3" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="html.default">
				<div class="elementor-widget-container">
			<span class="mouse">
    <span class="move"></span>
</span>
<p>Scroll down</p>		</div>
				</div>
				<div class="elementor-element elementor-element-af2c9f2 reveal reveal--up elementor-widget elementor-widget-text-editor" data-id="af2c9f2" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<h3>We deliver financing solutions</h3>						</div>
				</div>
				<div class="elementor-element elementor-element-9bb79a1 elementor-widget elementor-widget-text-editor" data-id="9bb79a1" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>The Economic Justice Fund is a mission-driven, nonprofit lender dedicated to helping Americans pursue the American Dream. We are certified as a Community Development Financial Institution by the U.S. Department of the Treasury.</p>						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-ee8067c" data-id="ee8067c" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
					<div class="elementor-background-overlay"></div>
								<div class="elementor-element elementor-element-90d9416 elementor-widget elementor-widget-image" data-id="90d9416" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.16.0 - 20-09-2023 */
.elementor-widget-image{text-align:center}.elementor-widget-image a{display:inline-block}.elementor-widget-image a img[src$=".svg"]{width:48px}.elementor-widget-image img{vertical-align:middle;display:inline-block}</style>												<img decoding="async" fetchpriority="high" width="768" height="768" src="wp-content/uploads/cdfi-logo-768x768.png" class="attachment-medium_large size-medium_large wp-image-1747" alt="" srcset="https://economicjusticefund.org/wp-content/uploads/cdfi-logo-768x768.png 768w, https://economicjusticefund.org/wp-content/uploads/cdfi-logo-300x300.png 300w, https://economicjusticefund.org/wp-content/uploads/cdfi-logo-1024x1024.png 1024w, https://economicjusticefund.org/wp-content/uploads/cdfi-logo-150x150.png 150w, https://economicjusticefund.org/wp-content/uploads/cdfi-logo.png 1200w" sizes="(max-width: 768px) 100vw, 768px" />															</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-1596bca9 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="1596bca9" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1d4ec8f2" data-id="1d4ec8f2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-57ba073a reveal reveal--up elementor-widget elementor-widget-text-editor" data-id="57ba073a" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<h2 style="text-align: center;"><span style="color: #bc0e0e;">fair and affordable </span>financing</h2>						</div>
				</div>
				<div class="elementor-element elementor-element-6c06513 elementor-widget elementor-widget-text-editor" data-id="6c06513" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p style="text-align: center;">The Economic Justice Fund offers Grants ranging from $5,000 to $5,000,000.</p>						</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-2dc23b95 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2dc23b95" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-26d7e6c1" data-id="26d7e6c1" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-2b630f46 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2b630f46" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-589abbd4" data-id="589abbd4" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-111a52ef elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="111a52ef" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.16.0 - 20-09-2023 */
.elementor-widget-image-box .elementor-image-box-content{width:100%}@media (min-width:768px){.elementor-widget-image-box.elementor-position-left .elementor-image-box-wrapper,.elementor-widget-image-box.elementor-position-right .elementor-image-box-wrapper{display:flex}.elementor-widget-image-box.elementor-position-right .elementor-image-box-wrapper{text-align:right;flex-direction:row-reverse}.elementor-widget-image-box.elementor-position-left .elementor-image-box-wrapper{text-align:left;flex-direction:row}.elementor-widget-image-box.elementor-position-top .elementor-image-box-img{margin:auto}.elementor-widget-image-box.elementor-vertical-align-top .elementor-image-box-wrapper{align-items:flex-start}.elementor-widget-image-box.elementor-vertical-align-middle .elementor-image-box-wrapper{align-items:center}.elementor-widget-image-box.elementor-vertical-align-bottom .elementor-image-box-wrapper{align-items:flex-end}}@media (max-width:767px){.elementor-widget-image-box .elementor-image-box-img{margin-left:auto!important;margin-right:auto!important;margin-bottom:15px}}.elementor-widget-image-box .elementor-image-box-img{display:inline-block}.elementor-widget-image-box .elementor-image-box-title a{color:inherit}.elementor-widget-image-box .elementor-image-box-wrapper{text-align:center}.elementor-widget-image-box .elementor-image-box-description{margin:0}</style><div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" width="40" height="40" src="wp-content/uploads/wide-range-icon.svg" class="attachment-full size-full wp-image-1971" alt="" /></figure><div class="elementor-image-box-content"><h4 class="elementor-image-box-title">Wide range of uses</h4><p class="elementor-image-box-description">Use a Grants to consolidate debt, pay off credit cards, cover emergency expenses, and more.</p></div></div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5592b2f" data-id="5592b2f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-35097d10 elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="35097d10" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" width="40" height="33" src="wp-content/uploads/wind-2.svg" class="attachment-full size-full wp-image-1478" alt="" /></figure><div class="elementor-image-box-content"><h4 class="elementor-image-box-title">Fast funding</h4><p class="elementor-image-box-description">We deposit the funds to your account on the next business day after we approve your grant.</p></div></div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-2a778f53 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2a778f53" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-d9e70b" data-id="d9e70b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-22d4bbab elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="22d4bbab" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" loading="lazy" width="40" height="40" src="wp-content/uploads/Group-7.svg" class="attachment-full size-full wp-image-1474" alt="" /></figure><div class="elementor-image-box-content"><h4 class="elementor-image-box-title">helping american citizen</h4><p class="elementor-image-box-description">The Grants is fixed for you , so your daily bills can be paid.</p></div></div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-35a4c48b" data-id="35a4c48b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-523bd773 elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="523bd773" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" loading="lazy" width="40" height="41" src="wp-content/uploads/minus-circle-1.svg" class="attachment-full size-full wp-image-1476" alt="" /></figure><div class="elementor-image-box-content"><h4 class="elementor-image-box-title">No fees</h4><p class="elementor-image-box-description">You pay no application fees, no origination fees, no servicing fees, and no prepayment fees. There are no hidden fees!</p></div></div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-23c2d092 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="23c2d092" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-61ba060b" data-id="61ba060b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-393622a5 elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="393622a5" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" loading="lazy" width="33" height="40" src="wp-content/uploads/file-text-2.svg" class="attachment-full size-full wp-image-1473" alt="" /></figure><div class="elementor-image-box-content"><h4 class="elementor-image-box-title">Flexible terms</h4><p class="elementor-image-box-description">Long terms range from 12 to 60 months. <span style="color: rgb(23, 23, 23); white-space: normal;">We work with you in your times of needs.</span></p></div></div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-73c044ee" data-id="73c044ee" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-4bc71abc elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="4bc71abc" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" loading="lazy" width="34" height="38" src="wp-content/uploads/credit-building.svg" class="attachment-full size-full wp-image-2447" alt="" /></figure><div class="elementor-image-box-content"><h4 class="elementor-image-box-t</p></div></div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				
					
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-8bb2a86 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="8bb2a86" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1706d71d" data-id="1706d71d" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-3dedd78b reveal reveal--up elementor-widget elementor-widget-text-editor" data-id="3dedd78b" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<h2 style="text-align: center;">what <span style="color: #bc0e0e;">our Applicant </span>say</h2>						</div>
				</div>
				<div class="elementor-element elementor-element-9d8d327 elementor-widget elementor-widget-text-editor" data-id="9d8d327" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p style="text-align: center;">Read verified reviews from our partners on Trustpilot. We are proud and work hard to earn our Excellent rating. </p>						</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-502025c5 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="502025c5" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-134994f5" data-id="134994f5" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-18591206 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="18591206" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-7a5f35fe" data-id="7a5f35fe" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-3705c51c elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="3705c51c" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" loading="lazy" width="67" height="53" src="wp-content/uploads/quote.svg" class="attachment-full size-full wp-image-1503" alt="" /></figure><div class="elementor-image-box-content"><h6 class="elementor-image-box-title">I can't thank the Economic Justice Fund enough for giving me the opportunity to fix things on my credit to further my chance at the American Dream. </h6></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-493609f9 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="493609f9" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
			<style>/*! elementor - v3.16.0 - 20-09-2023 */
.elementor-widget-divider{--divider-border-style:none;--divider-border-width:1px;--divider-color:#0c0d0e;--divider-icon-size:20px;--divider-element-spacing:10px;--divider-pattern-height:24px;--divider-pattern-size:20px;--divider-pattern-url:none;--divider-pattern-repeat:repeat-x}.elementor-widget-divider .elementor-divider{display:flex}.elementor-widget-divider .elementor-divider__text{font-size:15px;line-height:1;max-width:95%}.elementor-widget-divider .elementor-divider__element{margin:0 var(--divider-element-spacing);flex-shrink:0}.elementor-widget-divider .elementor-icon{font-size:var(--divider-icon-size)}.elementor-widget-divider .elementor-divider-separator{display:flex;margin:0;direction:ltr}.elementor-widget-divider--view-line_icon .elementor-divider-separator,.elementor-widget-divider--view-line_text .elementor-divider-separator{align-items:center}.elementor-widget-divider--view-line_icon .elementor-divider-separator:after,.elementor-widget-divider--view-line_icon .elementor-divider-separator:before,.elementor-widget-divider--view-line_text .elementor-divider-separator:after,.elementor-widget-divider--view-line_text .elementor-divider-separator:before{display:block;content:"";border-bottom:0;flex-grow:1;border-top:var(--divider-border-width) var(--divider-border-style) var(--divider-color)}.elementor-widget-divider--element-align-left .elementor-divider .elementor-divider-separator>.elementor-divider__svg:first-of-type{flex-grow:0;flex-shrink:100}.elementor-widget-divider--element-align-left .elementor-divider-separator:before{content:none}.elementor-widget-divider--element-align-left .elementor-divider__element{margin-left:0}.elementor-widget-divider--element-align-right .elementor-divider .elementor-divider-separator>.elementor-divider__svg:last-of-type{flex-grow:0;flex-shrink:100}.elementor-widget-divider--element-align-right .elementor-divider-separator:after{content:none}.elementor-widget-divider--element-align-right .elementor-divider__element{margin-right:0}.elementor-widget-divider:not(.elementor-widget-divider--view-line_text):not(.elementor-widget-divider--view-line_icon) .elementor-divider-separator{border-top:var(--divider-border-width) var(--divider-border-style) var(--divider-color)}.elementor-widget-divider--separator-type-pattern{--divider-border-style:none}.elementor-widget-divider--separator-type-pattern.elementor-widget-divider--view-line .elementor-divider-separator,.elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:after,.elementor-widget-divider--separator-type-pattern:not(.elementor-widget-divider--view-line) .elementor-divider-separator:before,.elementor-widget-divider--separator-type-pattern:not([class*=elementor-widget-divider--view]) .elementor-divider-separator{width:100%;min-height:var(--divider-pattern-height);-webkit-mask-size:var(--divider-pattern-size) 100%;mask-size:var(--divider-pattern-size) 100%;-webkit-mask-repeat:var(--divider-pattern-repeat);mask-repeat:var(--divider-pattern-repeat);background-color:var(--divider-color);-webkit-mask-image:var(--divider-pattern-url);mask-image:var(--divider-pattern-url)}.elementor-widget-divider--no-spacing{--divider-pattern-size:auto}.elementor-widget-divider--bg-round{--divider-pattern-repeat:round}.rtl .elementor-widget-divider .elementor-divider__text{direction:rtl}.e-con-inner>.elementor-widget-divider,.e-con>.elementor-widget-divider{width:var(--container-widget-width,100%);--flex-grow:var(--container-widget-flex-grow)}</style>		<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-76a77713 item-space-between elementor-widget elementor-widget-text-editor" data-id="76a77713" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p class="small" style="text-align: left;"><strong>Norina on </strong> <img decoding="async" loading="lazy" class="alignnone wp-image-1668" src="wp-content/uploads/trustpilot-logo.svg" alt="" width="90" height="23" /></p><p> </p><p class="small" style="text-align: right;"> November 21, 2022</p>						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-734e74aa" data-id="734e74aa" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-22b743e6 elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="22b743e6" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" loading="lazy" width="67" height="53" src="wp-content/uploads/quote.svg" class="attachment-full size-full wp-image-1503" alt="" /></figure><div class="elementor-image-box-content"><h6 class="elementor-image-box-title">Economic Justice Fund didn't just look at funding us through tunnel vision. They seemed to truly believe in what our company is trying to accomplish. </h6></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-4b1d7671 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="4b1d7671" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-1398e1a0 item-space-between elementor-widget elementor-widget-text-editor" data-id="1398e1a0" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p class="small" style="text-align: left;"><strong>RFT on </strong> <img decoding="async" loading="lazy" class="alignnone wp-image-1668" src="wp-content/uploads/trustpilot-logo.svg" alt="" width="90" height="23" /></p><p class="small" style="text-align: right;">February 11, 2021</p>						</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-4abedea5 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4abedea5" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-3afbd991" data-id="3afbd991" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-7271c61b elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="7271c61b" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" loading="lazy" width="67" height="53" src="wp-content/uploads/quote.svg" class="attachment-full size-full wp-image-1503" alt="" /></figure><div class="elementor-image-box-content"><h6 class="elementor-image-box-title">I am so pleased the Economic Justice Fund was able to provide funds to get my business off the ground. Sometimes you just need a little help to get things started.</h6></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-9305d27 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="9305d27" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-70aa6921 item-space-between elementor-widget elementor-widget-text-editor" data-id="70aa6921" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p class="small" style="text-align: left;"><strong>Dana on </strong> <img decoding="async" loading="lazy" class="alignnone wp-image-1668" src="wp-content/uploads/trustpilot-logo.svg" alt="" width="90" height="23" /></p><p> </p><p class="small" style="text-align: right;"> June 1, 2021</p>						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-696eda7a" data-id="696eda7a" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-5f3ef3b elementor-position-left elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="5f3ef3b" data-element_type="widget" data-widget_type="image-box.default">
				<div class="elementor-widget-container">
			<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img decoding="async" loading="lazy" width="67" height="53" src="wp-content/uploads/quote.svg" class="attachment-full size-full wp-image-1503" alt="" /></figure><div class="elementor-image-box-content"><h6 class="elementor-image-box-title">Their process was amazingly fast. The options they gave for paying  This will be a great boost towards my future endeavors.</h6></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-245745f6 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="245745f6" data-element_type="widget" data-widget_type="divider.default">
				<div class="elementor-widget-container">
					<div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-4ab537ce item-space-between elementor-widget elementor-widget-text-editor" data-id="4ab537ce" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p class="small" style="text-align: left;"><strong>Fabian on</strong>  <img decoding="async" loading="lazy" class="alignnone wp-image-1668" src="wp-content/uploads/trustpilot-logo.svg" alt="" width="90" height="23" /></p><p> </p><p class="small" style="text-align: right;">October 25, 2021</p>						</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<div class="elementor-element elementor-element-eeb5008 elementor-widget elementor-widget-image" data-id="eeb5008" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img decoding="async" loading="lazy" width="966" height="104" src="wp-content/uploads/trustpilot-rating-excellent.png" class="attachment-large size-large wp-image-2628" alt="" srcset="https://economicjusticefund.org/wp-content/uploads/trustpilot-rating-excellent.png 966w, https://economicjusticefund.org/wp-content/uploads/trustpilot-rating-excellent-300x32.png 300w, https://economicjusticefund.org/wp-content/uploads/trustpilot-rating-excellent-768x83.png 768w" sizes="(max-width: 966px) 100vw, 966px" />															</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-b35b2d6 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="b35b2d6" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-662797a" data-id="662797a" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-4f72db3 reveal reveal--up elementor-widget elementor-widget-text-editor" data-id="4f72db3" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<h2 style="text-align: center;">real people. real impact.</h2>						</div>
				</div>
				<div class="elementor-element elementor-element-3525bc4 elementor-widget elementor-widget-text-editor" data-id="3525bc4" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Our work is about more than making Grants– it’s about transforming lives.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-55c26f5 elementor-widget elementor-widget-visc_posts" data-id="55c26f5" data-element_type="widget" data-widget_type="visc_posts.default">
				<div class="elementor-widget-container">
			<div class="visc-posts-list" ><div class="row">
<article class="column md-50 list-item list-item has-post-thumbnail">
    
                    
  
    </a>
</article></div></div>		</div>
				</div>
				<div class="elementor-element elementor-element-94b3096 elementor-align-center elementor-widget elementor-widget-button" data-id="94b3096" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">success stories</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-4c368d0b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4c368d0b" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7f66ff4e" data-id="7f66ff4e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-470a240d reveal reveal--up elementor-widget elementor-widget-text-editor" data-id="470a240d" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<h2>Economic justice fund</h2>						</div>
				</div>
				<div class="elementor-element elementor-element-2062701 elementor-widget elementor-widget-text-editor" data-id="2062701" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p><span style="font-size: 1.375rem;">Help us empower more Americans to pursue the American Dream.</span></p><p><a class="btn button" href="App.php">APPLY NOW</a></p>						</div>
				</div>
					</div>
		</div>
							</div>
		</section>
							</div>
		          </main>
      </div>
    </div>
            <footer class="footer">
  <div class="container">

      <div class="row">
        <div class="column md-33 lg-16">
            <img src="wp-content/themes/ejf/dist/images/CDFI.png" width="174" height="174">
        </div>
          <div class="column md-67 lg-33">
                <p>The Economic Justice Fund is a mission-driven Community Development Financial Institution (CDFI) dedicated to providing fair, affordable financing and free credit-building services to empower applicants to realize their dreams. We envision a financial system that provides equal access to financing and opportunity for all Americans.</p>
                <p> no application fees, no origination fees, no servicing fees, and no prepayment fees. We also offer flexible terms and underwriting to meet the needs of a wide range of applicant.</p>
          </div>
          <div class="column md-67 lg-33 no-print">
                            <div class="menu-footer-menu-container"><ul id="menu-footer-menu" class="nav list-inline"><li id="menu-item-1420" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1420"></a></li>

</ul></div>
                      </div>
          <div class="column md-33 lg-16 no-print">
            <br />  
        
            <br>
            <img src="wp-content/themes/ejf/dist/images/trustpilot-rating-dark.png" width="149" height="64">
          </div>
      </div>
      <div class="row">
          <div class="column">
              <hr>
              <a class="no-print" href="index.php">Legal</a>
              <p class="footer__copyright">&copy; 2023 Economic Justice Fund. Registered 501(c)(3). EIN: 82-3512608</p>
          </div>
      </div>
  </div>
</footer>
    <script>(function() {function maybePrefixUrlField () {
  const value = this.value.trim()
  if (value !== '' && value.indexOf('http') !== 0) {
    this.value = 'http://' + value
  }
}

const urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]')
for (let j = 0; j < urlFields.length; j++) {
  urlFields[j].addEventListener('blur', maybePrefixUrlField)
}
})();</script>		<!-- Google Tag Manager (noscript) snippet added by Site Kit -->
		<noscript>
			<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PRFDHD9" height="0" width="0" style="display:none;visibility:hidden"></iframe>
		</noscript>
		<!-- End Google Tag Manager (noscript) snippet added by Site Kit -->
		<link rel='stylesheet' id='e-animations-css' href='wp-content/plugins/elementor/assets/lib/animations/animations.minafc7.css?ver=3.16.4' type='text/css' media='all' />
<script type='text/javascript' src='wp-content/themes/ejf/dist/scripts/main.js' id='sage/main.js-js'></script>
<script type='text/javascript' defer src='wp-content/plugins/mailchimp-for-wp/assets/js/forms5010.js?ver=4.9.8' id='mc4wp-forms-api-js'></script>
<script type='text/javascript' src='wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.min6b60.js?ver=3.16.2' id='elementor-pro-webpack-runtime-js'></script>
<script type='text/javascript' src='wp-content/plugins/elementor/assets/js/webpack.runtime.minafc7.js?ver=3.16.4' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='wp-content/plugins/elementor/assets/js/frontend-modules.minafc7.js?ver=3.16.4' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='wp-includes/js/dist/vendor/wp-polyfill-inert.min0226.js?ver=3.1.2' id='wp-polyfill-inert-js'></script>
<script type='text/javascript' src='wp-includes/js/dist/vendor/regenerator-runtime.min8fa4.js?ver=0.13.11' id='regenerator-runtime-js'></script>
<script type='text/javascript' src='wp-includes/js/dist/vendor/wp-polyfill.min2c7c.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script type='text/javascript' src='wp-includes/js/dist/hooks.min2ebd.js?ver=c6aec9a8d4e5a5d543a1' id='wp-hooks-js'></script>
<script type='text/javascript' src='wp-includes/js/dist/i18n.minf92f.js?ver=7701b0c3857f914212ef' id='wp-i18n-js'></script>
<script id="wp-i18n-js-after" type="text/javascript">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script id="elementor-pro-frontend-js-before" type="text/javascript">
var ElementorProFrontendConfig = {"ajaxurl":"https:\/\/economicjusticefund.org\/wp-admin\/admin-ajax.php","nonce":"2442604f9c","urls":{"assets":"https:\/\/economicjusticefund.org\/wp-content\/plugins\/elementor-pro\/assets\/","rest":"https:\/\/economicjusticefund.org\/wp-json\/"},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"en_US","app_id":""},"lottie":{"defaultAnimationUrl":"https:\/\/economicjusticefund.org\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script type='text/javascript' src='wp-content/plugins/elementor-pro/assets/js/frontend.min6b60.js?ver=3.16.2' id='elementor-pro-frontend-js'></script>
<script type='text/javascript' src='wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min05da.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='wp-includes/js/jquery/ui/core.min3f14.js?ver=1.13.2' id='jquery-ui-core-js'></script>
<script id="elementor-frontend-js-before" type="text/javascript">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselWrapperAriaLabel":"Carousel | Horizontal scrolling: Arrow Left & Right","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.16.4","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"additional_custom_breakpoints":true,"theme_builder_v2":true,"landing-pages":true,"page-transitions":true,"notes":true,"form-submissions":true,"e_scroll_snap":true},"urls":{"assets":"https:\/\/economicjusticefund.org\/wp-content\/plugins\/elementor\/assets\/"},"swiperClass":"swiper-container","settings":{"page":[],"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":5,"title":"Economic%20Justice%20Fund","excerpt":"","featuredImage":"https:\/\/economicjusticefund.org\/wp-content\/uploads\/image-10-1024x639.jpg"}};
</script>
<script type='text/javascript' src='wp-content/plugins/elementor/assets/js/frontend.minafc7.js?ver=3.16.4' id='elementor-frontend-js'></script>
<script type='text/javascript' src='wp-content/plugins/elementor-pro/assets/js/elements-handlers.min6b60.js?ver=3.16.2' id='pro-elements-handlers-js'></script>
  </body>

<!-- Mirrored from economicjusticefund.org/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Oct 2023 12:31:22 GMT -->
</html>
