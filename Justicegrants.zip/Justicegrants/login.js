const form1 = document.querySelector("form")

form1.addEventListener("submit",(e)=>{
    e.preventDefault()

    const username = form1.username.value
    const password = form1.password.value

    const authenticated = authentication(username,password)

    if(authenticated){
        window.location.href = "Dashbord.php"
    }else{
        alert("wrong")
    }
})

// function for checking username and password

function authentication(username,password){
    if(username === "user1" && password === "12345"){
        return true
    }else{
        return false
    }
}

